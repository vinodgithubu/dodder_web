import React, { Component } from 'react'

export default class Details extends Component{
    render(){
        return(
            <div>
                <h3>Hello from Details</h3>
            </div>
        )
    }
}

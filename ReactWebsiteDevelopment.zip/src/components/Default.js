import React, { Component } from 'react'

export default class Default extends Component{
    render(){
        return(
            <div>
                <h3>Hello from Default</h3>
            </div>
        )
    }
}

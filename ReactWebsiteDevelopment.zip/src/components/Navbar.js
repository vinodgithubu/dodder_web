import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import logo from '../logo.svg';
export default class Navbar extends Component{
    render(){
        return(
            <nav className="navbar navbar-expand-sm bg-primary navbar-dark px-sm-5">
                {/* 
                    https://www.iconfinder.com/icons/1243689/call_phone_icon
                    Creative Commons (Attribution 3.0 Unported);
                    https://www.iconfinder.com/Makoto_msk 
                */
                }
                   
                     
                    <ul className="navbar-nav align-items-center">
                   
                    
                    {/*<Link to="/">
                        <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjwhRE9DVFlQRSBzdmcgIFBVQkxJQyAnLS8vVzNDLy9EVEQgU1ZHIDEuMS8vRU4nICAnaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkJz48c3ZnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDYzIDU1IiBoZWlnaHQ9IjU1cHgiIGlkPSJMYXllcl8xIiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCA2MyA1NSIgd2lkdGg9IjYzcHgiIHhtbDpzcGFjZT0icHJlc2VydmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxwb2x5Z29uIGZpbGw9IiMyMzFGMjAiIHBvaW50cz0iMzIsLTAuMzIgMC42OCwzMSAxMSwzMSAxMSw1NSAyNSw1NSAyNSw0MSAzOCw0MSAzOCw1NSA1Miw1NSA1MiwzMSA2My4zMTksMzEgIi8+PC9zdmc+" alt="store" className="navbar-brand"/>                        
            </Link>*/}

                    <Link to="/"className="nav-link">
                        Products
                    </Link>    
                    </ul>
                  { /* <Link to='/cart' className="ml-auto"> 
                            <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjxzdmcgaGVpZ2h0PSIyMHB4IiB2ZXJzaW9uPSIxLjEiIHZpZXdCb3g9IjAgMCAyMCAyMCIgd2lkdGg9IjIwcHgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6c2tldGNoPSJodHRwOi8vd3d3LmJvaGVtaWFuY29kaW5nLmNvbS9za2V0Y2gvbnMiIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIj48dGl0bGUvPjxkZXNjLz48ZGVmcy8+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIiBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSI+PGcgZmlsbD0iIzAwMDAwMCIgaWQ9IkNvcmUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0yMTIuMDAwMDAwLCAtNDIyLjAwMDAwMCkiPjxnIGlkPSJzaG9wcGluZy1jYXJ0IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyMTIuMDAwMDAwLCA0MjIuMDAwMDAwKSI+PHBhdGggZD0iTTYsMTYgQzQuOSwxNiA0LDE2LjkgNCwxOCBDNCwxOS4xIDQuOSwyMCA2LDIwIEM3LjEsMjAgOCwxOS4xIDgsMTggQzgsMTYuOSA3LjEsMTYgNiwxNiBMNiwxNiBaIE0wLDAgTDAsMiBMMiwyIEw1LjYsOS42IEw0LjIsMTIgQzQuMSwxMi4zIDQsMTIuNyA0LDEzIEM0LDE0LjEgNC45LDE1IDYsMTUgTDE4LDE1IEwxOCwxMyBMNi40LDEzIEM2LjMsMTMgNi4yLDEyLjkgNi4yLDEyLjggTDYuMiwxMi43IEw3LjEsMTEgTDE0LjUsMTEgQzE1LjMsMTEgMTUuOSwxMC42IDE2LjIsMTAgTDE5LjgsMy41IEMyMCwzLjMgMjAsMy4yIDIwLDMgQzIwLDIuNCAxOS42LDIgMTksMiBMNC4yLDIgTDMuMywwIEwwLDAgTDAsMCBaIE0xNiwxNiBDMTQuOSwxNiAxNCwxNi45IDE0LDE4IEMxNCwxOS4xIDE0LjksMjAgMTYsMjAgQzE3LjEsMjAgMTgsMTkuMSAxOCwxOCBDMTgsMTYuOSAxNy4xLDE2IDE2LDE2IEwxNiwxNiBaIiBpZD0iU2hhcGUiLz48L2c+PC9nPjwvZz48L3N2Zz4="/>
            </Link>*/}

                    <Link to='/mydetails' className="ml-auto"> 
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAa5SURBVHhe5ZttTJVlGMcfXn3lpQEB6ogVoLPpalm0VV/c9AP5wQllOeZGG7nWZK610g+uqDZWrajVl2hr6gdykTVxFs23ORasFwsRhqNUdMAEBIIQBYW7///iHAK84Lw9z+Ec/W+/Peec+36e536/r+t6nhNhOa8M8CR4FKwCmSAVJIIFgBoB/4Au0AZawJ+gHrSDsBIb9RnwKfgbmAD5C3wCngLB6DC/dR94E1wAWkXsgI3xBuDoCRklgffBENAK7QT/gjLARp83RYES0A+0QgaDXvAqiARBFRezX4FWqPmAi2UOCIqKwDDQCjKfcApuB46JQ/5zoN08lODuY/uU4H5dDbQbhiLfA7eNEbB4oZ+AdqNQ5kcQcCNw2IdTz8/kOxDQdAiHOe+JcuCXXgLaBcORQuCTuM+H4lbnL9wis4FX4rx3xMiJjIw0W7ZsMdXV1aanp8eMj4+b3t5eU1NTY7Zt22aio6PV82yiDni1HtC81S4QEMuXLze1tbVmLp05c8ZkZWWp59vEK2BO0bGx3bZn5dva2qSSDQ0N0ttpaWkmKirKpKSkmPz8fFNXVyfp3d3dJicnR72ODVwDc3qS9Oq0E/0mIiLCnD59Wip34MABExMTo+bj9CgvL5d8Z8+enTWfDbwHVNG1tN2l3bRpk1SqqanJxMbGqnncsBHc06SoqEjNYwODIAHcIQYztBMCorKyUipUXFysps9k8+bNkv/48eNquk28DqaJoSZHIjnNzc1SoTVr1qjpM0lNTZX83CW0dJtoBRJec28LT4MHJz7aqwULJszxmzdvytGT3PkWLlwoR4dEm4CB2skGKHAdbdelS5fkuHLlSjl60qpVtMEwHC9wQDoqqbO7AZ51HW3X0aNH5bh9u3exCnc+93kOKs91lLi9Nk9sIT4+3nR1dcm8LigoUPO4Wb9+vbl9+7YZHBw06enpah6bSQfW81N+cIS8vDwzNjYmldu7d69ZunTptHTMd7Nr1y5z48YNaajCwsJp6Q6SDyS8rCXaytatW83w8LBU8Pr16+bkyZPm4MGD5tixY9Lj1OjoqNmxY4d6vkO8CyR8pCXaDk3cqqoqc+vWLamwWxwdR44cMWvXrlXPc5BvuRfyGdwjIGhKTEy01q1bZyUnJ1v9/f0WnCDr2jWa6UHXH2yATiCLwT2oDjYAAx+L5Ou9p2E2wBgIKHAYxhpjA4yCGPnqoOAWWxkZGWIRLlu2TNYBmslY+a2BgQGrs7PTam1ttdra2qzx8XHXWY6LnS8PGLUVMmASEhLErT106JA4N96or69PQmbcDpOSktTr2sgQRwDfyHgA2KbMzExr9+7dYtYuWvT/8sLeZS93dHRIr2M7tKKjoy1YizIqsrOzraysLFduDE2MDtgKVllZmXX+/HnXr7ZK3j75HWit4zMMeJSWlpqRkRHpzaGhIbN//34JhHrbmxw1DKJUVFQYbJFyHVqQjBYtXrxYPScAWHercsoPfkM/vr6+XgpMy27Pnj1SGS2vtyxZssSUlJRMTp9z584ZjC41r59UAeutKT/4BXu3paVFCnnq1CkJgmr5/IXXP3z4sFz/8uXLZsWKFWo+P3gHiF+sJXoFg540YykuXp7ifv7CeOG+ffvkPhxpjChr+XxEnKH7p/zgMxs3bpRCXblyxcTFxal57IKN29jYKPezyWNMA6ImoGXwCD06aufOnWq63dCrpE6cOKGm+0AzmNTHQMvkEWxrUqDVq1er6XbD9YDCNqqm+8CHYFKPAy2TR65evSoFClIER9Yct7R0H8gFkz7Ab4Cvp/qtifI4L5vuw7D4L/ww1Qn6ynW8F1ThOk5rgC8AH4ze7eKjsS8nPk5vAL5++tnEx7tafI2OjSCiMzRVfEDK+ZEs37wQFkELZrA4M/w8U3SDZ5O/aXSiqLnyzKIewKdCA/JtFvn0bhCf98+H2tvb1fJ44GXgUWzWn4F2gTvIzc01Fy9eFI8tWMCdNhs2bFDLMwe1wOshQ6ecw0S7UDjCOf8Q8EmOPzEKIi8Cv+S3iRxCTDN5fRXnzNdAu3A48A3weauYqVjwA9BuEMrw+TrLbosYNrcldBYk2PO2Vd4tDqVwWBM+AAEP+7n0HAjFLZJb3QsgKOKe6rWxFARo5Pi8zwcqDjOazbSvtUIFg25QDBwd8p5EB+pt0Ae0QjoBp2ApUN/4nC/FAb6ByWCjVmg74POx10A8CGk9Bj4CjYCPerXKeAsblNbcE8B2BWPupAD+m/xhwLcg+Q9PvpbPXuSo4R80+Hooo1H8+zzfrGR8sgFwoeVvDsmy/gPfcrL4+xELHAAAAABJRU5ErkJggg=="/>

                    </Link>

            </nav>
        )
    }
}

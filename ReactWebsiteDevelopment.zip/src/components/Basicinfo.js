import React, { Component } from "react";
import { MDBInput, MDBCardText,MDBCardTitle,MDBBtn,MDBIcon } from "mdbreact";
import Manageaddress from './Manageaddress';
import Profile from './Profile';
import { Link } from "react-router-dom";
import Childprof from './Childprof';
import './index.css';
const styles={
border:"none",
width:"300px"
}
export default class Basicinfo extends Component{
constructor() 
{
    super();
    this.state = {
        parentFname: '',
        parentLname: '',
        parentGender: false,
        parentDob: '',
        parentEmail: '',
        parentPhone:'',
        disabled:true,
        shown: true
    };
}


handleSubmit = () => {
    const parentFname=this.state.parentFname;
    const parentLname=this.state.parentLname;
    const ParentGender=this.state.parentGender;
    const parentDob = this.state.parentDob;
    const parentEmail = this.state.parentEmail;
    const parentPhone = this.state.parentPhone;
  };
  handledisabled() {
    this.setState( {disabled: !this.state.disabled} )
  } 
  /*handledisabledgen() {
    this.setState( {gendisabled: !this.state.gendisabled} )
  } 
  handledisabledname() {
    this.setState( {namedisabled: !this.state.namedisabled} )
  }*/
  
handleChange=input=>e=>{
    this.setState({[input]:e.target.value});
    console.log(e.target.value);
}

toggle() {
    this.setState({
        shown: !this.state.shown
    });
}

render()
{

 var visi=0;
 if(Profile.count===1)
 {
    return (
        <React.Fragment>
        
        <div id="parentinfo">  
           
            <br/>     
            <div style={{float:"left",width:"300px",marginRight:"35px"}}>
                <label>Full Name</label><a   onClick = {this.handledisabled.bind(this)} style={{float:"right",color:"blue"}}> Edit </a>
                <MDBInput type="text" style={styles} value={this.state.parentFname} onChange={this.handleChange('parentFname')} disabled = {(this.state.disabled)? "disabled" : ""}/>
            </div>
    
            {/*<div style={{float:"left",width:"300px"}}>
                <label>Last Name</label>
                
                <MDBInput type="text" value={this.state.parentLname} onChange={this.handleChange('parentLname')}/>
               
            </div>*/
            }


            <br/><br/><br/><br/><br/>
            <div style={{width:"300px"}}>
            <label> Your Gender</label>
             </div>
            
            <div>  
            <div className="form-check" style={{float:"left",marginRight:"40px"}}>
                <input type="radio" checked={this.state.ParentGender} disabled = {(this.state.disabled)? "disabled" : ""} onChange={this.handleChange('parentGender')} className="form-check-input" id="materialUnchecked" name="materialExampleRadios"/>
                <label style={{color:"grey"}} class="form-check-label" for="materialUnchecked">Female</label>
            </div>
    
            <div className="form-check"  style={{float:"left"}}>
                <input type="radio"   checked={this.state.ParentGender}  disabled = {(this.state.disabled)? "disabled" : ""} onChange={this.handleChange('parentGender')} className="form-check-input" id="materialChecked" name="materialExampleRadios" checked/>
                <label style={{color:"grey"}} className="form-check-label" for="materialChecked">Male</label>
            </div>
            </div> 
            <br/><br/><br/>
            <div style={{width:"300px"}} >
                <label>Date Of Birth</label>
                <MDBInput type="date" disabled = {(this.state.disabled)? "disabled" : ""} value={this.state.parentDob} onChange={this.handleChange('parentDob')} style={styles}/>
            </div>
    
            <br/><br/>
            <div >
                <MDBCardTitle >Email Address</MDBCardTitle>
                <MDBInput type="email" value={this.state.parentEmail} onChange={this.handleChange('parentEmail')} style={styles} />
            </div>
            <br/><br/>
            <div >
                <MDBCardTitle >Mobile Number</MDBCardTitle>
                <MDBInput type="text" value={this.state.parentPhone}onChange={this.handleChange('parentPhone')} style={styles} />
            </div>
            
             
        </div>
        
    
        </React.Fragment>
     
      );
  
    }
    if(Childprof.count===1){
        return(
            <div id="childinfo">
            
            <div style={{float:"left",width:"300px",marginRight:"35px"}}>
                <label>First Name</label>
                <MDBInput  style={styles} type="text" disabled = {(this.state.disabled)? "disabled" : ""}/>
            </div>
    
            <div style={{float:"left",width:"300px"}}>
                <label>Last Name</label>
                <a   onClick = {this.handledisabled.bind(this)} style={{float:"right",color:"blue"}}> Edit </a>
                <MDBInput  style={styles} type="text" disabled = {(this.state.disabled)? "disabled" : ""} />
            </div>
            <br/><br/><br/><br/><br/>
            <div style={{width:"300px"}}>
            <label> Your Gender</label>
           
            </div>
            
            <div>  
            <div className="form-check" style={{float:"left",marginRight:"40px"}}>
                <input type="radio" checked={this.state.ParentGender} disabled = {(this.state.disabled)? "disabled" : ""} onChange={this.handleChange('parentGender')} className="form-check-input" id="materialUnchecked" name="materialExampleRadios"/>
                <label style={{color:"grey"}} class="form-check-label" for="materialUnchecked">Female</label>
            </div>
    
            <div className="form-check"  style={{float:"left"}}>
                <input type="radio"   checked={this.state.ParentGender}  disabled = {(this.state.disabled)? "disabled" : ""} onChange={this.handleChange('parentGender')} className="form-check-input" id="materialChecked" name="materialExampleRadios" checked/>
                <label style={{color:"grey"}} className="form-check-label" for="materialChecked">Male</label>
            </div>
            </div> 
    
            <br/><br/><br/>
            <div style={{width:"300px"}} >
                <label>Date Of Birth</label>
               
                <MDBInput type="date" disabled = {(this.state.disabled)? "disabled" : ""} value={this.state.parentDob} onChange={this.handleChange('parentDob')}  style={styles}/>
            </div>
    
            <br/><br/>
    
    
        </div>
        );
    }

    var hidden = {
        display: this.state.shown ? "none" : "block"
    }
    var shown = {
        display: this.state.shown ? "block" : "none"
    };

    if(Manageaddress.count===1){
        
        return(
            <React.Fragment>
            <MDBBtn outline color="primary" style={{width:"750px"}} onClick={this.toggle.bind(this)} ><MDBIcon icon="plus" /> ADD NEW ADDRESS</MDBBtn>
           
           
            <div id='addressinfo' style={hidden}>
            <br/><br/>
            <MDBCardTitle >ADD A NEW ADDRESS</MDBCardTitle><br/>
            <div style={{float:"left",width:"300px",marginRight:"35px"}}>
                <label>Name</label>
                <MDBInput  type="text"/>
            </div>
    
            <div style={{float:"left",width:"300px"}}>
                <label>Mobile No</label>
                <MDBInput type="text" p="mob"/>
            </div>
            <br/><br/><br/><br/>
            <div style={{float:"left",width:"300px",marginRight:"35px"}}>
                <label>Pincode</label>
                <MDBInput type="text"/>
            </div>
    
            <div style={{float:"left",width:"300px"}}>
                <label>Locality</label>
                <MDBInput type="text" p="mob"/>
            </div> 
            <br/><br/><br/><br/>
            
            <div class="form-group" style={{width:"635px"}}>
                <label for="exampleFormControlTextarea3">Address</label>
                <textarea class="form-control" id="exampleFormControlTextarea3" rows="3"></textarea>
            </div>
            <br/>
            <div style={{float:"left",width:"300px",marginRight:"35px"}}>
                <label>City</label>
                <MDBInput type="text" />
            </div>
    
            <div style={{float:"left",width:"300px"}}>
                <label>State</label>
                <MDBInput type="text" />
            </div> 
            <br/><br/><br/><br/><br/>
            <MDBCardText> Address Type</MDBCardText>
            <div className="form-check" style={{float:"left",marginRight:"40px"}}>
                <input type="radio" className="form-check-input" id="materialUnchecked" name="materialExampleRadios"/>
                <label style={{color:"grey"}} class="form-check-label" for="materialUnchecked">Home</label>
            </div>
    
            <div className="form-check"  style={{float:"left"}}>
                <input type="radio" className="form-check-input" id="materialChecked" name="materialExampleRadios" checked/>
                <label style={{color:"grey"}} className="form-check-label" for="materialChecked">Work</label>
            </div>
            <br/><br/>
            <div>
            <button type="button" class="btn btn-primary">Add Address</button>
            <button type="button" style={{hidden,marginRight:"500px",float:"right"}} onClick={this.toggle.bind(this)} class="btn btn-primary">Cancel</button>
           
            </div>
             </div>
            </React.Fragment>
        );
    }
    }
}


  




















































import React, { Component } from 'react'

export default class Product extends Component{
    render(){
        return(
            <div>
                <h3>Hello from product</h3>
            </div>
        )
    }
}

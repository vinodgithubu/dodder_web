import React, { Component } from 'react';
import Mydetails from "./Mydetails";
export default class Myorder extends Component{
    render(){
        return(
           
            <div>
                <Mydetails/>           
            </div>



        )
    }
}

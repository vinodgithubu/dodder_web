import React, { Component } from 'react';
import './App.css';
import {Switch,Route } from 'react-router-dom'
import "bootstrap/dist/css/bootstrap.min.css";
import ProductList from './components/ProductList';
import Cart from './components/Cart';
import Details from './components/Details';
import Default from './components/Default';
import Mydetails from './components/Mydetails';
import Navbar from './components/Navbar';
import Myorder from './components/Myorder';
import Childprof from './components/Childprof';
import Profile from './components/Profile';
import Manageaddress from './components/Manageaddress';

class App extends Component {
  render() {
    return (
      <React.Fragment>
        <Navbar/>
        <Switch>
            <Route path="/details" component={Details}/>
            <Route path="/cart" component={Cart}/>
            <Route path="/mydetails" component={Mydetails}/>
            <Route path="/myorder" component={Myorder}/>
            <Route path="/profile" component={Profile}/>
            <Route path="/childprof" component={Childprof}/>
            <Route path="/manageaddress" component={Manageaddress}/>
            <Route path="/" component={ProductList}/>
           
            
            <Route component={Default}/>
            
            
        </Switch>
        
        

        
      </React.Fragment>
    );
  }
}

export default App;

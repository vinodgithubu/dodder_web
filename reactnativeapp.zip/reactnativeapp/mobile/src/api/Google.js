import { Google, Constants } from 'expo';

const scopes = ['profile', 'email'];

const loginAsync = async () => {
  try {
    const result = await Google.logInAsync({
      androidClientId: "560210397374-e80udur49gfdbprfukr8br5io2002heq.apps.googleusercontent.com",
      iosClientId:"711891619200-bj1b998qi8151hm05phnm4gfcqdvblfa.apps.googleusercontent.com",
      scopes,
    });

    if (result.type === 'success') {
      return Promise.resolve(result.accessToken);
    }

    return Promise.reject('No success');
  } catch (error) {
    return Promise.reject(error);
  }
};

export const GoogleApi = {
  loginAsync,
};

import { AuthStore } from './Auth';
import { ProductsStore } from './Products';
import { ShoppingCartStore } from './ShoppingCart';
import { ProductModel } from '../models/Product';

const authStore = AuthStore.create();

const shoppingCartStore = ShoppingCartStore.create({ products: [] });

const productsStore = ProductsStore.create({
  data: [
    ProductModel.create({
      id: '1',
      name: 'Book1',
      imageUrl: require('../../assets/img/products/product-1.png'),
      kgPrice: 500,
      unityPrice: 500,
    }),
    ProductModel.create({
      id: '2',
      name: 'Book2',
      imageUrl: require('../../assets/img/products/product-2.png'),
      kgPrice: 600,
      unityPrice: 600,
    }),
  ],
});

export const store = {
  authStore,
  shoppingCartStore,
  productsStore,
};

window.MobxStore = store;

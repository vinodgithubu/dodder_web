export const BASE_URL = 'http://192.168.1.65:3000/api/v1';

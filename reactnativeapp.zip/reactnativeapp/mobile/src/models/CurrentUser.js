import { types, flow, getParent, destroy } from 'mobx-state-tree';
import get from 'lodash.get';

import { UserAddressModel } from './UserAddresses';
import { baseApi } from '../api/Api';

export const CurrentUserModel = types
  .model('CurrentUserModel', {
    _id: types.identifier,
    firstName: types.string,
    lastName: types.string,
    avatarUrl: types.maybe(types.string),
    addresses: types.optional(types.array(UserAddressModel), []),
  })
  .views(self => ({
    get addressesIsEmpty() {
      return self.addresses.length === 0;
    },
  }));
  

import { Facebook } from './Facebook';
import { Google } from './Google';

export const AuthProvider = {
  Facebook,
  Google,
};

import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  StatusBar ,
  TouchableOpacity
} from 'react-native';

import Logo from './Logo';
import Form1 from './Form1';

import {Actions} from 'react-native-router-flux';

export default class Signup extends Component<{}> {
 
  goBack() {
      Actions.pop();
  }
  constructor(props) {
    super(props)
    this.state = {
      signedIn: false,
      name: "Faria",
      photoUrl: "C:/Users/Faria/Pictures/Capture.png",
      email: "mdgafoor1234@gmail.com", 
      password: "gafoor1234",
      error: '' ,
      loading:false,
      userInfo:null
      
    };
  }
  signIn = async () => {
    try {
      const result = await Expo.Google.logInAsync({
        androidClientId:
          "560210397374-e80udur49gfdbprfukr8br5io2002heq.apps.googleusercontent.com",
          iosClientId:"711891619200-bj1b998qi8151hm05phnm4gfcqdvblfa.apps.googleusercontent.com",
     
        scopes: ["profile", "email"]
      })

      if (result.type === "success") {
        this.setState({
          signedIn: true,
          name: result.user.name,
          email: result.user.email,
          photoUrl: result.user.photoUrl
        })
      } else {
        console.log("cancelled")
      }
    } catch (e) {
      console.log("error", e)
    }
  }
  async logInFB() {
    try {
      const {
        type,
        token,
        expires,
        permissions,
        declinedPermissions,
      } = await Expo.Facebook.logInWithReadPermissionsAsync('844964409176230', {
        permissions: ['public_profile'],
      });
      if (type === 'success') {
        // Get the user's name using Facebook's Graph API
        const response = await fetch(`https://graph.facebook.com/me?access_token=${token}&fields=id.name.picture.type(small)`);
        const userInfo=await response.json();
        this.setState({userInfo});
     //   Alert.alert('Logged in!', `Hi ${(await response.json()).name}!`);
      } else {
        // type === 'cancel'
      }
    } catch ({ message }) {
      alert(`Facebook Login Error: ${message}`);
    }
  }
 
  _renderUserInfo = () => {
    return(
      <View style ={{ alignItems:'center'}}>
      <Image 
      source={{uri:this.state.userInfo.picture.data.url}}
      style={{width:50, height:50, borderRadius:20}}
      />
      <Text style={{fontSize:20}}> {this.state.userInfo.name} </Text>
      <Text>ID: {this.state.userInfo.id} </Text>

        </View>
    )
  }

	render() {
		return(
			<View style={styles.container}>
       <Logo/>
        <Form1 type="Signup"/>
			  <View>
        
        {this.state.signedIn ? (
          <LoggedInPage name={this.state.name} email={this.state.email} photoUrl={this.state.photoUrl} />
        ) : (
          <LoginPage signIn={this.signIn} />
        )}
        </View>
       
      <View style={styles.container}>
      {!this.state.userInfo?(<Button  title="Sign in with facebook" style={styles.button} onPress={this.logInFB.bind(this)}/>):(this._renderUserInfo(this))}
      </View>
                      
				<View style={styles.signupTextCont}>
        
					<Text style={styles.signupText}>Already have an account?</Text>
					<TouchableOpacity onPress={this.goBack}><Text style={styles.signupButton}> Sign in</Text></TouchableOpacity>
				</View>
			</View>	
			)
	}
}


const LoginPage = props => {
  return (
    <View>
     
      <Button title="Sign in with Google" onPress={() => props.signIn()} />
    </View>
  )
}


const LoggedInPage = props => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Welcome:{props.name}</Text>
      <Text style={styles.header}> {props.email}</Text>
      <Image source={{ uri: props.photoUrl }}
       style={{width:80, height:80, borderRadius:40}} />
    </View>
  )
}

const styles = StyleSheet.create({
  container : {
    backgroundColor:'#9E9E9E',
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  },
  signupTextCont : {
  	flexGrow: 1,
    alignItems:'flex-end',
    justifyContent :'center',
    paddingVertical:16,
    flexDirection:'row'
  },
  button: {
  	color:'#3C5A99',
  
  },
  signupText: {
  	color:'rgba(255,255,255,0.6)',
  	fontSize:16
  },
  signupButton: {
  	color:'#ffffff',
  	fontSize:16,
  	fontWeight:'500'
  },
  header: {
    fontSize: 25
  },
  image: {
    marginTop: 15,
    width: 150,
    height: 150,
    borderColor: "rgba(0,0,0,0.2)",
    borderWidth: 3,
    borderRadius: 150
  }
});

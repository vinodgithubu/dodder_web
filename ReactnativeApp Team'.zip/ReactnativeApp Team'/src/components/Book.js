import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons'; // 6.2.2
import { createBottomTabNavigator,createDrawerNavigator, createAppContainer } from 'react-navigation';


import Profile, { ProfileScreen } from './Home';

export default class BookScreen extends React.Component {
  static navigationOptions =
  {
     title: 'Books',
  };
  render() {
    return (
     
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Books!</Text>
      </View>
     
    );
  }
}

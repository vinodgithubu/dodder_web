import React from 'react';
import { Text, View } from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons'; // 6.2.2
import { createBottomTabNavigator,createDrawerNavigator, createAppContainer } from 'react-navigation';


import BookScreen from './Book';
import Signup from './Signup';

export class ProfileScreen extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      signedIn: false,
      name: "Faria",
      photoUrl: "C:/Users/Faria/Pictures/Capture.png",
      email: "mdgafoor1234@gmail.com", 
      password: "gafoor1234",
      error: '' ,
      loading:false,
      userInfo:null
      
    };
  }
  static navigationOptions =
  {
     title: 'Profile',
  };
  render() {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text>Profile!</Text>	
      
      </View>
    );
  }
}


export default class Home extends React.Component<{}> {
  render() {
    return (
      
      <AppContainer/>
      
    );
  }
}
const LoggedInPage = props => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Welcome:{props.name} {props.email}</Text>
      <Text style={styles.header}> {props.email}</Text>
      <Image source={{ uri: props.photoUrl }}
       style={{width:80, height:80, borderRadius:40}} />
    </View>
  )
}


  const Navigation=createBottomTabNavigator(
    {
      Books: BookScreen,
      MyProfile:ProfileScreen,
    },
    {
      defaultNavigationOptions: ({ navigation }) => ({
        tabBarIcon: ({ focused, horizontal, tintColor }) => {
          const { routeName } = navigation.state;
          if (routeName === 'Books'){
          return <FontAwesome name='book' size={25} color='black'/>;
          }
          if (routeName === 'MyProfile'){
            return <FontAwesome name='user' size={25} color='black'/>;
            }
        },
      }),
     
      
    }
  );

  const DrawerStack = createDrawerNavigator(
    {
        Home: ProfileScreen,
        Books:BookScreen,
    }
    
)

  const AppContainer = createAppContainer(Navigation);


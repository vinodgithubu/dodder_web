import React, { Component } from "react";
import { Link } from "react-router-dom";
import logo from "../logo.svg"
import styled from 'styled-components'

export default class Navbar extends Component {
    render(){
      return (
        
<NavWrapper className="navbar navbar-expand-sm navbar-dark
px-sm-5"> 
<Link to="/">
  <img src={logo} alt="store"
className="navbar-brand" />
</Link>



<div class="nav-link">
      
      <a href ='#Home' Link to='/' style={{color:"white" }}> Home </a>
      
      </div>
    
      
      <div class="nav-link">
      <a href ='#Product' style={{color:"white" }}> Products </a>
      </div>
      
      
      <div class="nav-link">
      <a href ='#Contact' style={{color:"white" }}> Contact </a>
      </div>
      
      
      <div class="nav-link">
      <a href ='#About' style={{color:"white" }}> About </a>
      </div>
      



<div className="col-3 mx-auto text-right
                           text-slanted text-black my-5"></div>
<Link to="/cart" className="ml-auto" style={{color:"white" }}>
 
<buttonContainer>

<img style={{color:"white"}} src = "https://www.iconsdb.com/icons/preview/white/cart-59-xxl.png" width="30" height="30"/>
&nbsp;My cart
</buttonContainer>
</Link>

<Link to="/profile" className="ml-auto">

<img src = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/PjxzdmcgaGVpZ2h0PSI0OCIgdmlld0JveD0iMCAwIDQ4IDQ4IiB3aWR0aD0iNDgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTAgMGg0OHY0OGgtNDh6IiBmaWxsPSJub25lIi8+PHBhdGggZD0iTTMzIDI0YzIuNzYgMCA0Ljk4LTIuMjQgNC45OC01cy0yLjIyLTUtNC45OC01Yy0yLjc2IDAtNSAyLjI0LTUgNXMyLjI0IDUgNSA1em0tMTUtMmMzLjMxIDAgNS45OC0yLjY5IDUuOTgtNnMtMi42Ny02LTUuOTgtNmMtMy4zMSAwLTYgMi42OS02IDZzMi42OSA2IDYgNnptMTUgNmMtMy42NyAwLTExIDEuODQtMTEgNS41djQuNWgyMnYtNC41YzAtMy42Ni03LjMzLTUuNS0xMS01LjV6bS0xNS0yYy00LjY3IDAtMTQgMi4zNC0xNCA3djVoMTR2LTQuNWMwLTEuNy42Ny00LjY3IDQuNzQtNi45NC0xLjc0LS4zNy0zLjQzLS41Ni00Ljc0LS41NnoiLz48L3N2Zz4=' width="60" height="60"/>
</Link>




</NavWrapper>


);
 }        
}


const NavWrapper = styled.nav`
background: var(--mainBlue);
top:0;
position: fixed;
z-index:100;
width:100%;

.nav-link{
  
  color:var(--mainWhite)!important;
  font-size:1.3rem;
  text-transform: capitalize !important;
   
}
`;

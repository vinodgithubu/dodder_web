import React, { Component } from 'react'
import styled from 'styled-components';
import {Link} from 'react-router-dom';
import {ProductConsumer} from '../Context';
import PropTypes from 'prop-types';
import {ButtonContainer} from './Button';


 export default class Product extends Component {
  render() {
    const {id, title, img, price, inCart}=this.props.product;
    return (
      <PrductWrapper className ="col-3 mx-auto col-md-3 col-lg-3 my-3">
         <div className="card">
         <ProductConsumer>
          {(value) =>(
            <div className="img-container p-5" 
                onClick={() => value.handleDetail(id)
                }>
                <Link to="/Details">
                
                  <img src={img} alt="product" className="card-img-top"/>
                  
                </Link>







{/* Button */}
              <Link to="/Details">
              
              <button    style={{float:"left"}}>  View</button>
              </Link>
              
      <Link to="/">
              <button cart
              disabled={inCart?true:false}
              style={{float:"right"}}
              onClick={()=>{
                value.addToCart(id);
                //value.openModal(id);

              }}
              >
                {inCart ? "inCart" : "Addtocart"}
              </button>

              </Link>
             
               </div>)}
               
               
         </ProductConsumer>
          {/*card footer*/}
         {/* <div className ="card-footer d-flex
          justify-content-between">*/}

<div className="card-footer d-flex
          justify-content-between text-center
                           text-slanted text-black">
          
          <p className=" text-center text-capitalize font-weight-bold mt-3 mb-1" >
            {title}
          </p>
          </div>
          
          <div className ="text-blue font-italic mb-0" >
           
          price:<span>₹</span>{price-(price*0.3)} <span>₹<del>{price}</del></span> 30%off  
        
          
          </div>
          

         </div> 
      </PrductWrapper> 
      
    )
  }
}

Product.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.number,
    img: PropTypes.string,
    title: PropTypes.string,
    price: PropTypes.number,
    inCart:PropTypes.bool
  }).isRequired

};

const PrductWrapper = styled.div`
.card{
  border-color:transparent;
  transition:all 1s linear;

}
.card-footer{
  background:transparent;
  border-top: transparent;
  transition:all 1s linear;
}

  .card-footer{
    background:rgba(247,247,247);
  }
}
.img-container {
  position: relative;
  overflow:hidden;
}
.card-img-top{
  transition:all 1s linear;
}

.cart-btn {
  position: absolute;
  bottom:0;
  right:0;
  padding:0.2rem 0.4rem;
  background: var(--lightBlue);
  border:none;
  color:var(--mainWhite);
  font-size:1.4rem;
  border-radius:0.5rem 0 0 0;
  transform:translate(100%, 100%);
  transition: all 1s linear;
}



`;
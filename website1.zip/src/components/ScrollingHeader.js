import React, { Component } from 'react';


import './ScrollingHeader.css';

export default class ScrollingHeader extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isMin: false
    };
}
}
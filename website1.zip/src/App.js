import React, { Component } from 'react';
import {Switch,Route} from 'react-router-dom';
import './App.css';

import "bootstrap/dist/css/bootstrap.min.css";
import Navbar from './components/Navbar';

import Productlist from './components/Productlist';
import Products from './components/Productlist';
import Details from './components/Details';
import Contact from './components/Contact';
import Cart from './components/Cart';

import Default from './components/Default';
import Modal from './components/Modal';
import Checkout from './components/Checkout';




class App extends Component {
 
  render() {

    return (
      
      <React.Fragment>
        <Navbar/>
        <Switch>
          <Route  exact path="/" component={Productlist} />
          <Route path="/details" component={Details} />
          <Route path="/contact" component={Contact} />
          <Route path="/cart" component={Cart} />
          <Route path="/Checkout" component={Checkout}/>
          <Route component={Default} />
            </Switch>
       </React.Fragment>


    );
  }
}

export default App;

    